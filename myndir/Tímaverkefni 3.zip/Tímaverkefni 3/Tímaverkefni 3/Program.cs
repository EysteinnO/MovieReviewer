﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tímaverkefni_3
{
    class Program
    {
        static void Main(string[] args)
        {
            int choice = 0;
            do
            {
                Console.WriteLine("CreditCard Application\r\n");
                Console.WriteLine("1. Withdrawal");
                Console.WriteLine("2. Check balance\r\n");

                Console.WriteLine("Bílakeppni");
                Console.WriteLine("");


                choice = Convert.ToInt32(Console.ReadLine());
                switch (choice)
                {
                    case 1:
                        /*
                        CreditCard Withdraw = new CreditCard();
                        Withdraw.Uttekt(double Withdrawal);*/
                        break;
                    case 2:
                        CreditCard Balance = new CreditCard();
                        Balance.BirtaCredit();
                        break;
                    case 3:
                        break;
                    case 4:
                        break;
                    case 5:
                        Console.WriteLine("Takk fyrir að nota forritið");
                        System.Threading.Thread.Sleep(1000);
                        Environment.Exit(0);
                        break;
                    case 6:
                        break;
                    default:
                        break;
                }
                Console.ReadKey();
            } while (choice != 5);


        }
    }
}
