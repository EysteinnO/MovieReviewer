﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tímaverkefni_3
{
    class CreditCard
    {
        private string Kortanumer = "5489-5391-2896-5894";
        private string Nafn_Korthafa = "Gunnar Gunnarsson";
        private double Balance = 450.000;
        private double Withdrawal;
        private double MaximumWidthdrawal = 150.000;

        public double CreditCardBalance {

            get
            {

                return Balance;
                return MaximumWidthdrawal;
                return Withdrawal;
            }
            set
            {
                
                Balance = value;
                MaximumWidthdrawal = value;
                Withdrawal = value;
            }

        }

        public string CreditCardInfo
        {
            get
            {
                return Kortanumer;
                return Nafn_Korthafa;
            }
            set
            {
                Kortanumer = value;
                Nafn_Korthafa = value;
            }
        }


        public void Uttekt (double Withdrawal)
        {           
            Console.WriteLine("Þú hefur valið úttekt af korti.");
            Console.WriteLine("Hversu mikið viltu taka af kortinu?");
            Withdrawal = Convert.ToDouble(Console.ReadLine());
            if (Withdrawal > MaximumWidthdrawal)
            {
                Console.WriteLine("Þessi úttekt er ekki leyfileg. Reyndu aftur");
            }
            else
            {
                Console.WriteLine("Þessi úttekt er leyfð.");
                Balance = Balance - Withdrawal;
                Console.WriteLine("Innistæða er núna: ", Balance);
            }
        }

        public void BirtaCredit ()
        {
            Console.WriteLine("Þú hefur valið að sjá innistöðu kortsins.");
            Console.WriteLine("Innistaða kortsins er: {0}",Balance);
        }


    }
}
